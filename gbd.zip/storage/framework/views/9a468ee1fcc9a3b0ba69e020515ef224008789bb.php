
<?php echo $__env->yieldContent('content'); ?>
<?php /**PATH E:\xampp\htdocs\ttech\resources\views/frontend/blocks/main/index.blade.php ENDPATH**/ ?>