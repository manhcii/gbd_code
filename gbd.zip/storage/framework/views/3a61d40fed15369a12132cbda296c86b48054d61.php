
<?php echo $__env->yieldContent('content'); ?>
<?php /**PATH /Users/tuannguyenduy/Sites/ttech/ttech/resources/views/frontend/blocks/main/index.blade.php ENDPATH**/ ?>