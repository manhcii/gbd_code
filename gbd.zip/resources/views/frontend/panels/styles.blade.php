<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;300;400;500;600;700&display=swap"
    rel="stylesheet" />
<link rel="stylesheet" href="{{ asset('themes/frontend/watches/bootstrap/css/bootstrap.min.css') }}" />
<link rel="stylesheet" href="{{ asset('themes/frontend/watches/swiper/swiper-bundle.min.css') }}" />
<link rel="stylesheet" href="{{ asset('themes/frontend/watches/css/style.css') }}" />
<link rel="stylesheet" href="{{ asset('themes/frontend/watches/css/fixed-positioning.css') }}" />

<script src="{{ asset('themes/frontend/watches/bootstrap/js/bootstrap.min.js') }}"></script>
@isset($web_information->source_code->header)
    {!! $web_information->source_code->header !!}
@endisset
