
@if ($block)
    @php
        $title = $block->json_params->title->{$locale} ?? $block->title;
        $brief = $block->json_params->brief->{$locale} ?? $block->brief;
        $content = $block->json_params->content->{$locale} ?? $block->content;
        $image = $block->image != '' ? $block->image : '';
        $image_background = $block->image_background != '' ? $block->image_background : '';
        $url_link = $block->url_link != '' ? $block->url_link : '';
        $url_link_title = $block->json_params->url_link_title->{$locale} ?? $block->url_link_title;

    @endphp
    <section class="profile">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 col-md-12 col-12 left-side">
                    <h3>{{ $brief }}</h3>
                    <h2>{{ $title }}</h2>
                    <p>{{ $content }}
                    </p>
                    <div class="d-flex align-items-center">
                        <a class="download" href="{{ $url_link }}" title="Tìm hiểu">
                            {{ $url_link_title }}
                        </a>
                        <a href="#" class="wrap-btn">
                            <img class="img-fluid w-100" src="{{ asset('themes/frontend/watches/images/icon/download.png') }}" alt="slide">
                        </a>
                    </div>
                </div>
                {{-- <div class="col-lg-7 col-md-12 col-12">
                    <div class="wrap-img">
                        <img class="img-fluid w-100" src="{{ $image }}" alt="Hồ sơ năng lực">
                    </div>
                </div> --}}
                <div class="col-lg-5 col-md-12 col-12 ">
                <div class="swiper introduce">
                    <div class="swiper-wrapper">
                      <div class="swiper-slide">Slide 1</div>
                      <div class="swiper-slide">Slide 2</div>
                      <div class="swiper-slide">Slide 3</div>
                      <div class="swiper-slide">Slide 4</div>
                    </div>
                  </div>
                </div>
            </div>
        </div>
    </section>
@endif
